-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24-Set-2022 às 01:21
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `serotoninabdd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro`
--

CREATE TABLE `cadastro` (
  `nome` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `senha` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cadastro`
--

INSERT INTO `cadastro` (`nome`, `email`, `senha`) VALUES
('Giovanna Laura', 'giovanna.laura@aluno.ifsp.edu.br', 'SENHAGI'),
('Giovanna Laura', 'giovanna.laura@aluno.ifsp.edu.br', 'SENHAGI'),
('Monica', 'monicaa@aluno.ifsp.edu.br', 'SENHAMONI'),
('Mayara', 'mayara@aluno.ifsp.edu.br', 'SENHAMAY'),
('Stephany', 'Stephany@aluno.ifsp.edu.br', 'SENHASTE'),
('SAULO', 'saulo@aluno.ifsp.edu.br', 'SENHASAULO'),
('Talita', 'talita@professora.ifsp.edu.br', 'SENHATALITA'),
('Niki', 'niki@aluno.ifsp.edu.br', 'SENHANIKI');

-- --------------------------------------------------------

--
-- Estrutura da tabela `feedback`
--

CREATE TABLE `feedback` (
  `mensagem` varchar(500) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `feedback`
--

INSERT INTO `feedback` (`mensagem`, `nome`, `email`) VALUES
('MENSAGEM.', 'Giovanna Laura', 'giovanna.laura@aluno.ifsp.edu.br'),
('MENSAGEM.', 'Giovanna Laura', 'giovanna.laura@aluno.ifsp.edu.br'),
('MENSAGEM.', 'Giovanna Laura', 'giovanna.laura@aluno.ifsp.edu.br'),
('MENSAGEM.', 'Giovanna Laura', 'giovanna.laura@aluno.ifsp.edu.br'),
('MENSAGEM.', 'Giovanna Laura', 'giovanna.laura@aluno.ifsp.edu.br'),
('MENSAGEM.', 'Giovanna Laura', 'giovanna.laura@aluno.ifsp.edu.br'),
('MENSAGEM.', 'Array', 'giovanna.laura@aluno.ifsp.edu.br'),
('MENSAGEM.', 'Giovanna Laura', 'giovanna.laura@aluno.ifsp.edu.br'),
('Esse site esta muito bem estruturado! Parabéns equipe Serotonina!', 'Mayara', 'mayara@aluno.ifsp.edu.br'),
('O design desta aplicação esta lindo! Parabéns equipe Serotonina!', 'Stephany', 'Stephany@aluno.ifsp.edu.br'),
('O conteúdo deste site é perfeito! Parabéns equipe Serotonina!', 'Monica', 'monicaa@aluno.ifsp.edu.br'),
('Esta aplicação esta muito bem feita! Parabéns equipe Serotonina!', 'Giovanna Laura', 'giovanna.laura@aluno.ifsp.edu.br'),
('Parabéns pela dedicação ao projeto equipe Serotonina!', 'Saulo', 'saulo@aluno.ifsp.edu.br'),
('A implementação do site está de parabéns!', 'Niki', 'Niki@aluno.ifsp.edu.br');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
